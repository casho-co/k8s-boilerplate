def exception_handler(exc, context):
    return 